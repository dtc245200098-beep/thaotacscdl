# AI Prompt Log

## Prompt 1

Trong MySQL, nếu tôi tạo Index cho một cột ngày tháng nhưng trong mệnh đề WHERE tôi lại viết YEAR(created_at)=2026 thì tại sao MySQL không sử dụng Index?

### Kết quả tìm hiểu

Hàm YEAR() làm thay đổi giá trị của cột trước khi so sánh. MySQL không thể sử dụng trực tiếp B-Tree Index trên created_at nên phải quét toàn bộ bảng (Full Table Scan).

---

## Prompt 2

SARGable trong SQL là gì?

### Kết quả tìm hiểu

SARGable (Search Argument Able) là điều kiện cho phép MySQL sử dụng Index để tìm kiếm dữ liệu hiệu quả. Các phép so sánh trực tiếp như =, >, >=, < hoặc BETWEEN thường là SARGable.

---

## Prompt 3

Khi thiết kế Composite Index (transaction_type, created_at), thứ tự cột có quan trọng không?

### Kết quả tìm hiểu

Có. Thứ tự cột ảnh hưởng đến khả năng lọc dữ liệu. Trong bài toán này transaction_type được lọc bằng dấu bằng (=) và created_at được lọc theo khoảng thời gian (Range), nên Index (transaction_type, created_at) phù hợp hơn.

---

## Prompt 4

Sự khác nhau giữa Full Table Scan và Index Scan là gì?

### Kết quả tìm hiểu

Full Table Scan đọc toàn bộ dữ liệu trong bảng. Index Scan sử dụng cấu trúc B-Tree để tìm trực tiếp vùng dữ liệu cần thiết, giúp giảm số bản ghi phải đọc và tăng hiệu năng truy vấn.
