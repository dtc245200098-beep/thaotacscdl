# Phân tích EXPLAIN trước và sau tối ưu

Trước khi tối ưu, truy vấn sử dụng các hàm YEAR(created_at) và MONTH(created_at) trong mệnh đề WHERE. Điều này làm cho MySQL không thể sử dụng Index trên cột created_at. Kết quả EXPLAIN thường hiển thị type = ALL, nghĩa là Full Table Scan. Hệ quản trị phải đọc toàn bộ bảng Transactions (khoảng 5 triệu bản ghi), làm giá trị rows rất lớn và gây tiêu tốn CPU.

Sau khi tối ưu, tạo Composite Index:

CREATE INDEX idx_type_date ON Transactions(transaction_type, created_at);

Đồng thời thay điều kiện YEAR/MONTH bằng điều kiện khoảng thời gian:

created_at >= '2026-06-01 00:00:00'
AND created_at < '2026-07-01 00:00:00'

Truy vấn trở thành SARGable và MySQL có thể sử dụng B-Tree Index. Trong EXPLAIN, cột type chuyển từ ALL sang range hoặc ref. Cột key hiển thị idx_type_date và số dòng trong cột rows giảm mạnh. Điều này giúp giảm thời gian thực thi, giảm tải CPU và hạn chế ảnh hưởng tới các giao dịch đang hoạt động của hệ thống PayFlow.
